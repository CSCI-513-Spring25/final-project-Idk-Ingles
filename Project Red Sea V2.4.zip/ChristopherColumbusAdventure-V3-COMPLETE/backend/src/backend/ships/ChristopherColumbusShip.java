package backend.ships;

import java.util.Stack;
import java.util.Random;

public class ChristopherColumbusShip {
    private int x, y;
    private Stack<int[]> history = new Stack<>();
    private final int SIZE = 18;

    public ChristopherColumbusShip(int startX, int startY) {
        this.x = startX;
        this.y = startY;
    }

    public void savePosition() {
        history.push(new int[]{x, y});
    }

    public void undoPosition() {
        if (!history.isEmpty()) {
            int[] last = history.pop();
            x = last[0];
            y = last[1];
        }
    }

    public void move(String dir) {
        switch (dir) {
            case "up" -> { if (y > 0) y--; }
            case "down" -> { if (y < SIZE - 1) y++; }
            case "left" -> { if (x > 0) x--; }
            case "right" -> { if (x < SIZE - 1) x++; }
        }
    }

    public int getX() { return x; }
    public int getY() { return y; }
}
