package backend.ships;

public abstract class PowerUpDecorator extends ChristopherColumbusShip {
    protected ChristopherColumbusShip baseShip;

    public PowerUpDecorator(ChristopherColumbusShip ship) {
        super(ship.getX(), ship.getY());
        this.baseShip = ship;
    }

    public abstract String getPower();
}
