package backend.ships;

import backend.strategy.ChaseStrategy;
import java.util.*;

public class PirateManager {
    private List<PirateShip> pirates = new ArrayList<>();
    private Stack<List<int[]>> history = new Stack<>();

    public void spawnPiratesForLevel(String level) {
        pirates.clear();
        int count = switch (level.toLowerCase()) {
            case "easy" -> 1;
            case "medium" -> 2;
            case "hard" -> 3;
            default -> 1;
        };
        Random rand = new Random();
        for (int i = 0; i < count; i++) {
            pirates.add(new PirateShip(rand.nextInt(18), rand.nextInt(18), new ChaseStrategy()));
        }
    }

    public void movePirates(int targetX, int targetY) {
        for (PirateShip pirate : pirates) {
            pirate.move(targetX, targetY);
        }
    }

    public void saveHistory() {
        List<int[]> snapshot = new ArrayList<>();
        for (PirateShip p : pirates) {
            snapshot.add(new int[]{p.getX(), p.getY()});
        }
        history.push(snapshot);
    }

    public void undoPirates() {
        if (!history.isEmpty()) {
            List<int[]> last = history.pop();
            for (int i = 0; i < pirates.size(); i++) {
                pirates.get(i).setPosition(last.get(i)[0], last.get(i)[1]);
            }
        }
    }

    public List<int[]> getPositions() {
        List<int[]> list = new ArrayList<>();
        for (PirateShip p : pirates) {
            list.add(new int[]{p.getX(), p.getY()});
        }
        return list;
    }
}
