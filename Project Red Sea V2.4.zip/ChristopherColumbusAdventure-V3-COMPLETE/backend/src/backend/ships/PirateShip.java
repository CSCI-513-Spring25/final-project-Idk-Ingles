package backend.ships;

import backend.strategy.Strategy;

public class PirateShip {
    private int x, y;
    private Strategy strategy;

    public PirateShip(int x, int y, Strategy strategy) {
        this.x = x;
        this.y = y;
        this.strategy = strategy;
    }

    public void move(int targetX, int targetY) {
        strategy.move(this, targetX, targetY);
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() { return x; }
    public int getY() { return y; }
}
