package backend.ships;

public class ShieldedShip extends PowerUpDecorator {

    public ShieldedShip(ChristopherColumbusShip ship) {
        super(ship);
    }

    @Override
    public String getPower() {
        return "Shielded";
    }

    public boolean isShielded() {
        return true;
    }
}
