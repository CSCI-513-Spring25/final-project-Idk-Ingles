package backend.monsters;

import java.util.*;

public class SeaMonsterManager {
    private List<SeaMonster> monsters = new ArrayList<>();
    private Stack<List<int[]>> history = new Stack<>();
    private final Random rand = new Random();
    private final int SIZE = 18;

    public SeaMonsterManager() {
        // Spawn 2 initial monsters
        monsters.add(new SeaMonster(rand.nextInt(SIZE / 2), rand.nextInt(SIZE / 2)));
        monsters.add(new SeaMonster(SIZE / 2 + rand.nextInt(SIZE / 2), SIZE / 2 + rand.nextInt(SIZE / 2)));
    }

    public void spawnNearShip(int shipX, int shipY) {
        int mx = Math.max(0, Math.min(SIZE - 1, shipX + rand.nextInt(3) - 1));
        int my = Math.max(0, Math.min(SIZE - 1, shipY + rand.nextInt(3) - 1));
        monsters.add(new SeaMonster(mx, my));
    }

    public void saveHistory() {
        List<int[]> snapshot = new ArrayList<>();
        for (SeaMonster m : monsters) {
            snapshot.add(new int[]{m.getX(), m.getY()});
        }
        history.push(snapshot);
    }

    public void undoMonsters() {
        if (!history.isEmpty()) {
            List<int[]> last = history.pop();
            monsters.clear();
            for (int[] pos : last) {
                monsters.add(new SeaMonster(pos[0], pos[1]));
            }
        }
    }

    public List<int[]> getPositions() {
        List<int[]> list = new ArrayList<>();
        for (SeaMonster m : monsters) {
            list.add(new int[]{m.getX(), m.getY()});
        }
        return list;
    }
}
