package backend.strategy;

import backend.ships.PirateShip;

public interface Strategy {
    void move(PirateShip pirate, int targetX, int targetY);
}
