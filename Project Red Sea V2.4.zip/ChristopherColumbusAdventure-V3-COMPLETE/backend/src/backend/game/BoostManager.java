package backend.game;

public class BoostManager {
    private int moveCounter = 0;
    private int boostEvery = 4;

    public void setLevel(String level) {
        switch (level.toLowerCase()) {
            case "easy" -> boostEvery = 2;
            case "medium" -> boostEvery = 4;
            case "hard" -> boostEvery = 5;
            default -> boostEvery = 4;
        }
    }

    public void incrementMoveCounter() {
        moveCounter++;
    }

    public boolean isBoostReady() {
        return moveCounter > 0 && moveCounter % boostEvery == 0;
    }

    public void resetMoveCounter() {
        moveCounter = 0;
    }
}
