package backend.game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WhirlpoolManager {
    private List<int[]> whirlpools = new ArrayList<>();
    private Random rand = new Random();
    private final int SIZE = 18;

    public void spawnWhirlpools() {
        whirlpools.clear();
        for (int i = 0; i < 4; i++) {
            int x = rand.nextInt(SIZE);
            int y = rand.nextInt(SIZE);
            whirlpools.add(new int[]{x, y});
        }
    }

    public List<int[]> getWhirlpools() {
        return whirlpools;
    }
}
