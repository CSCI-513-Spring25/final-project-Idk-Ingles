package backend.game;

import backend.monsters.SeaMonsterManager;
import backend.ships.ChristopherColumbusShip;
import backend.ships.PirateManager;
import backend.ships.ShieldedShip;
import com.google.gson.Gson;

import java.util.*;

public class GameState {
    private static GameState instance;
    private ChristopherColumbusShip ship;
    private PirateManager pirateManager;
    private SeaMonsterManager monsterManager;
    private BoostManager boostManager;
    private WhirlpoolManager whirlpoolManager;
    private List<int[]> treasures = new ArrayList<>();
    private List<int[]> islands = new ArrayList<>();
    private int moveCounter;
    private final int SIZE = 18;
    private String currentLevel;
    private boolean whirlpoolsSpawned = false;
    private int shieldUses;

    private GameState() {
        resetGame("easy");
    }

    public static GameState getInstance() {
        if (instance == null) {
            instance = new GameState();
        }
        return instance;
    }

    public String resetGame(String level) {
        this.currentLevel = level;
        this.ship = new ShieldedShip(new ChristopherColumbusShip(0, 0));
        this.pirateManager = new PirateManager();
        this.monsterManager = new SeaMonsterManager();
        this.boostManager = new BoostManager();
        this.whirlpoolManager = new WhirlpoolManager();
        this.treasures.clear();
        this.islands.clear();
        this.moveCounter = 0;
        this.whirlpoolsSpawned = false;

        switch (level.toLowerCase()) {
            case "easy" -> shieldUses = 3;
            case "medium" -> shieldUses = 2;
            case "hard" -> shieldUses = 1;
            default -> shieldUses = 1;
        }

        pirateManager.spawnPiratesForLevel(level);
        boostManager.setLevel(level);

        int treasureCount = level.equals("medium") ? 2 : 1;
        Random rand = new Random();
        while (treasures.size() < treasureCount) {
            int tx = rand.nextInt(SIZE);
            int ty = rand.nextInt(SIZE);
            if (Math.abs(tx - ship.getX()) + Math.abs(ty - ship.getY()) > 7) {
                treasures.add(new int[]{tx, ty});
            }
        }

        int islandCount = switch (level.toLowerCase()) {
            case "easy" -> 12;
            case "medium" -> 8;
            case "hard" -> 4;
            default -> 10;
        };
        while (islands.size() < islandCount) {
            int x = rand.nextInt(SIZE);
            int y = rand.nextInt(SIZE);
            islands.add(new int[]{x, y});
        }

        return "New Game Started";
    }

    public String move(String direction) {
        ship.savePosition();
        pirateManager.saveHistory();
        monsterManager.saveHistory();

        int moves = boostManager.isBoostReady() ? 4 : 1;
        for (int i = 0; i < moves; i++) {
            ship.move(direction);
        }

        pirateManager.movePirates(ship.getX(), ship.getY());
        monsterManager.spawnNearShip(ship.getX(), ship.getY());

        moveCounter++;
        if (!whirlpoolsSpawned && moveCounter >= 2) {
            whirlpoolManager.spawnWhirlpools();
            whirlpoolsSpawned = true;
        }

        boostManager.incrementMoveCounter();

        return "Moved " + direction;
    }

    public String undo() {
        ship.undoPosition();
        pirateManager.undoPirates();
        monsterManager.undoMonsters();
        return "Undo Successful";
    }

    public String getGameStateJson() {
        Map<String, Object> state = new HashMap<>();
        state.put("ccX", ship.getX());
        state.put("ccY", ship.getY());
        state.put("pirates", convertList(pirateManager.getPositions()));
        state.put("monsters", convertList(monsterManager.getPositions()));
        state.put("whirlpools", convertList(whirlpoolManager.getWhirlpools()));
        state.put("islands", convertList(islands));
        state.put("treasures", convertList(treasures));
        state.put("boostReady", boostManager.isBoostReady());
        state.put("shieldUses", shieldUses);
        return new Gson().toJson(state);
    }

    private List<Map<String, Integer>> convertList(List<int[]> positions) {
        List<Map<String, Integer>> result = new ArrayList<>();
        for (int[] pos : positions) {
            Map<String, Integer> map = new HashMap<>();
            map.put("x", pos[0]);
            map.put("y", pos[1]);
            result.add(map);
        }
        return result;
    }
}
