// App.tsx — Updated to show Boost and Shield Count

import React, { useState, useEffect } from 'react';
import './App.css';
import shipImg from './assets/ship.png';
import pirateImg from './assets/pirate.png';
import treasureImg from './assets/treasure.png';
import seamonsterImg from './assets/monster.png';
import whirlpoolImg from './assets/whirlpool.png';
import islandImg from './assets/island.png';
import logoImg from './assets/GameLogo.png';

interface Position { x: number; y: number; }

function App() {
  const SIZE = 18;

  const [ccX, setCcX] = useState(0);
  const [ccY, setCcY] = useState(0);
  const [treasures, setTreasures] = useState<Position[]>([]);
  const [pirates, setPirates] = useState<Position[]>([]);
  const [monsters, setMonsters] = useState<Position[]>([]);
  const [whirlpools, setWhirlpools] = useState<Position[]>([]);
  const [islands, setIslands] = useState<Position[]>([]);
  const [boostReady, setBoostReady] = useState(false);
  const [shieldUses, setShieldUses] = useState(0);
  const [level, setLevel] = useState('');
  const [gameStarted, setGameStarted] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [nameSubmitted, setNameSubmitted] = useState(false);
  const [moveCount, setMoveCount] = useState(0);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!gameStarted) return;
      if (e.key === 'ArrowUp') move('up');
      else if (e.key === 'ArrowDown') move('down');
      else if (e.key === 'ArrowLeft') move('left');
      else if (e.key === 'ArrowRight') move('right');
      else if (e.code === 'Space') boostMove();
      else if (e.key.toLowerCase() === 'u') undoMove();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameStarted, boostReady]);

  const startGame = async (selectedLevel: string) => {
    setLevel(selectedLevel);
    setMoveCount(0);
    setBoostReady(false);
    setGameStarted(true);
    await fetch(`/newgame?level=${selectedLevel}`);
    await loadGameState();
  };

  const newGame = () => {
    setGameStarted(false);
    setNameSubmitted(false);
    setPlayerName('');
  };

  const loadGameState = async () => {
    const res = await fetch('/play?dir=none');
    const data = await res.json();
    updateGameState(data);
  };

  const move = async (dir: string) => {
    const res = await fetch(`/play?dir=${dir}`);
    const data = await res.json();
    updateGameState(data);
    setMoveCount(prev => prev + 1);
    setBoostReady(data.boostReady ?? false);
    setShieldUses(data.shieldUses ?? 0);
    if (moveCount + 1 === 2) {
      alert('🌪️ Weather Alert: Whirlpools are emerging!');
    }
  };

  const boostMove = async () => {
    const res = await fetch('/play?dir=boost');
    const data = await res.json();
    updateGameState(data);
    setBoostReady(false);
  };

  const undoMove = async () => {
    const res = await fetch('/undo');
    const data = await res.json();
    updateGameState(data);
  };

  const updateGameState = (data: any) => {
    setCcX(data.ccX);
    setCcY(data.ccY);
    setTreasures(data.treasures || []);
    setPirates(data.pirates || []);
    setMonsters(data.monsters || []);
    setWhirlpools(data.whirlpools || []);
    setIslands(data.islands || []);
    setShieldUses(data.shieldUses || 0);
    setBoostReady(data.boostReady || false);
  };

  const renderCell = (x: number, y: number) => {
    if (ccX === x && ccY === y) return <img src={shipImg} alt="Ship" className="cell-img" />;
    if (treasures.some(t => t.x === x && t.y === y)) return <img src={treasureImg} alt="Treasure" className="cell-img" />;
    if (pirates.some(p => p.x === x && p.y === y)) return <img src={pirateImg} alt="Pirate" className="cell-img" />;
    if (monsters.some(m => m.x === x && m.y === y)) return <img src={seamonsterImg} alt="Monster" className="cell-img" />;
    if (whirlpools.some(w => w.x === x && w.y === y)) return <img src={whirlpoolImg} alt="Whirlpool" className="cell-img" />;
    if (islands.some(i => i.x === x && i.y === y)) return <img src={islandImg} alt="Island" className="cell-img" />;
    return null;
  };

  if (!nameSubmitted) {
    return (
      <div className="start-screen">
        <img src={logoImg} alt="Game Logo" className="logo" />
        <h1>Red Sea Treasure Hunt</h1>
        <div className="name-input">
          <input type="text" placeholder="Enter your name" value={playerName} onChange={e => setPlayerName(e.target.value)} />
        </div>
        <div className="button-group">
          <button onClick={() => setNameSubmitted(true)}>Continue</button>
        </div>
      </div>
    );
  }

  if (!gameStarted) {
    return (
      <div className="start-screen">
        <img src={logoImg} alt="Game Logo" className="logo" />
        <h1>Welcome {playerName} Columbus</h1>
        <div className="button-group">
          <button onClick={() => startGame('easy')}>Easy</button>
          <button onClick={() => startGame('medium')}>Medium</button>
          <button onClick={() => startGame('hard')}>Hard</button>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="top-banner">
        <img src={logoImg} alt="Logo" />
        Red Sea Treasure Hunt — {playerName} Columbus
      </div>
      <div className="game-container">
        <div className="instructions">
          <h2>Instructions</h2>
          <p>Use Arrow keys or buttons to move.</p>
          <p>Press <b>Space</b> to Boost (4 tiles).</p>
          <p>Press <b>U</b> to Undo.</p>
          <p>Boost Ready: {boostReady ? '✅' : '❌'}</p>
          <p>🛡️ Shield Uses Left: {shieldUses}</p>
          <p>Avoid 🏴‍☠️, 🐙 and 🌀. Find 💰!</p>
        </div>

        <div className="board">
          {Array.from({ length: SIZE }).map((_, row) => (
            <div key={row} className="board-row">
              {Array.from({ length: SIZE }).map((_, col) => (
                <div key={col} className="board-cell">{renderCell(col, row)}</div>
              ))}
            </div>
          ))}
        </div>

        <div className="controls">
          <button onClick={() => move('up')}>↑</button>
          <div>
            <button onClick={() => move('left')}>←</button>
            <button onClick={() => move('down')}>↓</button>
            <button onClick={() => move('right')}>→</button>
          </div>
          <button onClick={boostMove}>Boost</button>
          <button onClick={undoMove}>Undo</button>
          <button onClick={newGame}>New Game</button>
        </div>
      </div>
    </>
  );
}

export default App;
