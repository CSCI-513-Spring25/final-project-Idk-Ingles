package backend;
import java.util.ArrayList;
import java.util.List;

public class SeaMonsterGroup implements SeaEntity {
    private List<SeaEntity> monsters = new ArrayList<>();

    public void add(SeaEntity monster) {
        monsters.add(monster);
    }

    @Override
    public void move() {
        for (SeaEntity m : monsters) {
            m.move();
        }
    }

    @Override
    public int getX() {
        return monsters.isEmpty() ? -1 : monsters.get(0).getX();
    }

    @Override
    public int getY() {
        return monsters.isEmpty() ? -1 : monsters.get(0).getY();
    }
}
