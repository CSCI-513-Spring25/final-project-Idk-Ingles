package backend;
public class SeaMonster implements SeaEntity {
    private int x, y;

    public SeaMonster(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void move() {
        this.x = Math.max(0, x - 1); // move left simple
    }

    @Override
    public int getX() { return x; }
    @Override
    public int getY() { return y; }
}
