package backend;
public class ShipFactory {
    public static ChristopherColumbusShip createStandardShip(int x, int y) {
        return new ChristopherColumbusShip(x, y);
    }

    public static ChristopherColumbusShip createBoostedShip(int x, int y) {
        return new BoostedShip(new ChristopherColumbusShip(x, y));
    }

    public static ChristopherColumbusShip createShieldedShip(int x, int y) {
        return new ShieldedShip(new ChristopherColumbusShip(x, y));
    }
}
