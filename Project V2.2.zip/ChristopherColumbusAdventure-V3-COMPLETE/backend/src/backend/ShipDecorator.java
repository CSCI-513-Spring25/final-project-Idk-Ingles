package backend;
public abstract class ShipDecorator extends ChristopherColumbusShip {
    protected ChristopherColumbusShip decoratedShip;

    public ShipDecorator(ChristopherColumbusShip ship) {
        super(ship.getX(), ship.getY());
        this.decoratedShip = ship;
    }

    @Override
    public abstract String getDescription();
}
