package backend;
// Interface for pirate movement strategies.
public interface Strategy {
    void move(PirateShip pirate, int targetX, int targetY);
}
