package backend;
public class ShieldedShip extends ShipDecorator {
    public ShieldedShip(ChristopherColumbusShip ship) {
        super(ship);
    }

    @Override
    public String getDescription() {
        return decoratedShip.getDescription() + " + Shielded";
    }
}
