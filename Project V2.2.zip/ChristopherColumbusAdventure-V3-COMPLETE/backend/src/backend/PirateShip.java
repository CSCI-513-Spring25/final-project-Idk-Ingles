package backend;
// Observer + Strategy pirate movement
public class PirateShip {
    private int x, y;
    private Strategy strategy;

    public PirateShip(int x, int y, Strategy strategy) {
        this.x = x;
        this.y = y;
        this.strategy = strategy;
    }

    public void move(int targetX, int targetY) {
        strategy.move(this, targetX, targetY);
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void moveToward(int targetX, int targetY) {
        if (this.x < targetX) x++;
        else if (this.x > targetX) x--;
        if (this.y < targetY) y++;
        else if (this.y > targetY) y--;
    }
    
}
