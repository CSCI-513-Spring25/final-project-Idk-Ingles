package backend;

public class BoostedShip extends ShipDecorator {
    public BoostedShip(ChristopherColumbusShip ship) {
        super(ship);
    }

    @Override
    public String getDescription() {
        return decoratedShip.getDescription() + " + Boosted";
    }
}
