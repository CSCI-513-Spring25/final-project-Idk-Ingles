package backend;
public class PirateShipFactory {
    public static PirateShip createChaser(int x, int y) {
        return new PirateShip(x, y, new ChaseStrategy());
    }

    public static PirateShip createPatroller(int x, int y) {
        return new PirateShip(x, y, new PatrolStrategy());
    }
}
