package backend;
public interface SeaEntity {
    void move();
    int getX();
    int getY();
}
