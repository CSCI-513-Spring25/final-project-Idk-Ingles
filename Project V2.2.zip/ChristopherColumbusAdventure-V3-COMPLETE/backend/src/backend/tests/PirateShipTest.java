// JUnit test for Pirate Strategy logic (Chase vs Patrol)
package backend.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import backend.PirateShip;
import backend.ChaseStrategy;
import backend.PatrolStrategy;

public class PirateShipTest {

    @Test
    public void testChaseStrategyMovement() {
        PirateShip pirate = new PirateShip(0, 0, new ChaseStrategy());
        pirate.move(2, 2);

        assertEquals(1, pirate.getX());
        assertEquals(1, pirate.getY());
    }

    @Test
    public void testPatrolStrategyMovement() {
        PirateShip pirate = new PirateShip(0, 0, new PatrolStrategy());
        pirate.move(0, 0); // patrol step logic
        assertEquals(1, pirate.getX());
    }
}
