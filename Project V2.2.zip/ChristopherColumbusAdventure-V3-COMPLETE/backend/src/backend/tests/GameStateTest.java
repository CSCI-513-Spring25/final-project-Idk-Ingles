// JUnit test for GameState with undo/win checking
package backend.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import backend.GameState;

public class GameStateTest {

    @Test
    public void testSingletonInstance() {
        GameState instance1 = GameState.getInstance();
        GameState instance2 = GameState.getInstance();

        assertSame(instance1, instance2, "GameState should return same instance");
    }

    @Test
    public void testGameReset() {
        GameState game = GameState.getInstance();
        game.resetGame();

        assertEquals(0, game.getCCX());
        assertEquals(0, game.getCCY());
    }
}
