package backend;

import backend.game.GameState;
import com.google.gson.Gson;
import fi.iki.elonen.NanoHTTPD;

import java.io.IOException;
import java.util.Map;
import java.util.stream.Collectors;

public class GameServer extends NanoHTTPD {

    public GameServer() throws IOException {
        super(8080);
        start(5000, false);
        System.out.println("🚀 Server started at http://localhost:8080");
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        Map<String, String> params = session.getParameters().entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> e.getValue().get(0)
                ));

        Gson gson = new Gson();
        GameState game = GameState.getInstance();

        switch (uri) {
            case "/newgame" -> {
                String level = params.getOrDefault("level", "easy");
                game.resetGame(level);
                return newFixedLengthResponse(Response.Status.OK, "application/json", game.getGameStateJson());
            }
            case "/play" -> {
                String dir = params.getOrDefault("dir", "none");
                game.move(dir);
                return newFixedLengthResponse(Response.Status.OK, "application/json", game.getGameStateJson());
            }
            case "/undo" -> {
                game.undo();
                return newFixedLengthResponse(Response.Status.OK, "application/json", game.getGameStateJson());
            }
            default -> {
                return newFixedLengthResponse("Unknown Command");
            }
        }
    }

    public static void main(String[] args) {
        try {
            new GameServer();
        } catch (IOException e) {
            System.err.println("❌ Failed to start server");
            e.printStackTrace();
        }
    }
}
