package backend.monsters;

import java.util.*;

public class SeaMonsterManager {
    private List<SeaMonster> monsters = new ArrayList<>();
    private Stack<List<int[]>> history = new Stack<>();
    private final int SIZE = 18;
    private final int MAX_MONSTERS = 8;
    private final Random rand = new Random();
    private int moveCounter = 0;

    public SeaMonsterManager() {
        monsters.add(new SeaMonster(rand.nextInt(SIZE), rand.nextInt(SIZE)));
    }

    public void spawnNearShip(int x, int y) {
        moveCounter++;
        if (monsters.size() < MAX_MONSTERS && moveCounter % 4 == 0) {
            int mx = Math.max(0, Math.min(SIZE - 1, x + rand.nextInt(3) - 1));
            int my = Math.max(0, Math.min(SIZE - 1, y + rand.nextInt(3) - 1));
            monsters.add(new SeaMonster(mx, my));
        }
    }

    public void saveHistory() {
        List<int[]> snapshot = new ArrayList<>();
        for (SeaMonster m : monsters)
            snapshot.add(new int[]{m.getX(), m.getY()});
        history.push(snapshot);
    }

    public void undoMonsters() {
        if (!history.isEmpty()) {
            List<int[]> last = history.pop();
            monsters.clear();
            for (int[] pos : last)
                monsters.add(new SeaMonster(pos[0], pos[1]));
        }
    }

    public List<int[]> getPositions() {
        List<int[]> out = new ArrayList<>();
        for (SeaMonster m : monsters)
            out.add(new int[]{m.getX(), m.getY()});
        return out;
    }
}
