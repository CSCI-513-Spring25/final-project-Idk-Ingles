package backend.game;

public class BoostManager {
    private int moveCounter = 0;
    private int interval = 5; // default

    public void setLevel(String level) {
        switch (level.toLowerCase()) {
            case "easy" -> interval = 2;
            case "medium" -> interval = 4;
            case "hard" -> interval = 5;
            default -> interval = 3;
        }
    }

    public void incrementMoveCounter() {
        moveCounter++;
    }

    public boolean isBoostReady() {
        return moveCounter > 0 && moveCounter % interval == 0;
    }

    public void reset() {
        moveCounter = 0;
    }
}
