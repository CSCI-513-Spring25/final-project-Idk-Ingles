package backend.game;

import backend.monsters.SeaMonsterManager;
import backend.ships.ChristopherColumbusShip;
import backend.ships.PirateManager;
import backend.ships.ShieldedShip;
import com.google.gson.Gson;

import java.util.*;

public class GameState {
    private static GameState instance;
    private ChristopherColumbusShip ship;
    private PirateManager pirateManager;
    private SeaMonsterManager monsterManager;
    private BoostManager boostManager;
    private WhirlpoolManager whirlpoolManager;
    private List<int[]> treasures = new ArrayList<>();
    private List<int[]> islands = new ArrayList<>();
    private int moveCounter;
    private final int SIZE = 18;
    private boolean whirlpoolsSpawned = false;
    private int shieldUses;
    private boolean gameOver = false;
    private boolean boostArmed = false;

    private GameState() {
        resetGame("easy");
    }

    public static GameState getInstance() {
        if (instance == null) {
            instance = new GameState();
        }
        return instance;
    }

    public String resetGame(String level) {
        this.ship = new ShieldedShip(new ChristopherColumbusShip(0, 0));
        this.pirateManager = new PirateManager();
        this.monsterManager = new SeaMonsterManager();
        this.boostManager = new BoostManager();
        this.boostManager.setLevel(level);
        this.whirlpoolManager = new WhirlpoolManager();
        this.treasures.clear();
        this.islands.clear();
        this.moveCounter = 0;
        this.whirlpoolsSpawned = false;
        this.gameOver = false;
        this.boostArmed = false;

        pirateManager.spawnPiratesForLevel(level, ship.getX(), ship.getY());


        shieldUses = switch (level.toLowerCase()) {
            case "easy" -> 3;
            case "medium" -> 2;
            case "hard" -> 1;
            default -> 2;
        };
        ship.setShieldCount(shieldUses);

        Random rand = new Random();
        int treasureCount = level.equals("medium") ? 2 : 1;
        while (treasures.size() < treasureCount) {
            int x = rand.nextInt(SIZE), y = rand.nextInt(SIZE);
            if (Math.abs(x - ship.getX()) + Math.abs(y - ship.getY()) > 7)
                treasures.add(new int[]{x, y});
        }

        int islandCount = switch (level) {
            case "easy" -> 16;
            case "medium" -> 12;
            case "hard" -> 8;
            default -> 10;
        };
        while (islands.size() < islandCount) {
            islands.add(new int[]{rand.nextInt(SIZE), rand.nextInt(SIZE)});
        }

        return "New Game Started";
    }

    public String move(String direction) {
        if (gameOver) return "Game Over";

        boolean isBoost = direction.startsWith("boost-");
        String baseDir = isBoost ? direction.substring(6) : direction;

        ship.savePosition();
        pirateManager.saveHistory();
        monsterManager.saveHistory();

        if (isBoost && !boostManager.isBoostReady()) {
            return "Invalid move";
        }

        int steps = isBoost ? 3 : 1;
        for (int i = 0; i < steps; i++) {
            boolean valid = ship.move(baseDir);
            if (!valid) return "Invalid move";
        }
        // 🚨 Check for whirlpool after moving
for (int[] wp : whirlpoolManager.getPositions()) {
    if (wp[0] == ship.getX() && wp[1] == ship.getY()) {
        // 🌪 Teleport to random new location
        Random rand = new Random();
        int newX = rand.nextInt(SIZE);
        int newY = rand.nextInt(SIZE);
        ship.setPosition(newX, newY);
        break;
    }
}


        if (onIsland(ship.getX(), ship.getY())) {
            pirateManager.freezePiratesForTurns(3);

        }
        

        pirateManager.movePirates(ship.getX(), ship.getY(), islands);

        if (treasureAt(ship.getX(), ship.getY())) {
            gameOver = true;
            return "Victory";
        }

        if (pirateManager.checkCollision(ship)) {
            ship.consumeShield();
            shieldUses--;
            if (shieldUses <= 0) {
                gameOver = true;
                return "Game Over";
            }
        }

        monsterManager.spawnNearShip(ship.getX(), ship.getY());

        if (!whirlpoolsSpawned && ++moveCounter >= 2) {
            whirlpoolManager.spawnWhirlpools();
            whirlpoolsSpawned = true;
        }

        boostManager.incrementMoveCounter();
        return "Moved " + direction;
    }

    public String undo() {
        ship.undoPosition();
        pirateManager.undoPirates();
        monsterManager.undoMonsters();
        return "Undo Successful";
    }

    public String getGameStateJson() {
        Map<String, Object> state = new HashMap<>();
        state.put("ccX", ship.getX());
        state.put("ccY", ship.getY());
        state.put("pirates", convert(pirateManager.getPositions()));
        state.put("monsters", convert(monsterManager.getPositions()));
        state.put("islands", convert(islands));
        state.put("treasures", convert(treasures));
        state.put("whirlpools", convert(whirlpoolManager.getPositions()));
        state.put("boostReady", boostManager.isBoostReady());
        state.put("boostArmed", boostArmed);
        state.put("shieldUses", ship.getShieldCount());
        state.put("gameOver", gameOver);
        state.put("gameResult", gameOver && treasureAt(ship.getX(), ship.getY()) ? "win" :
                                shieldUses <= 0 ? "loss" : "none");
        return new Gson().toJson(state);
    }

    private boolean treasureAt(int x, int y) {
        for (int[] t : treasures)
            if (t[0] == x && t[1] == y)
                return true;
        return false;
    }

    private boolean onIsland(int x, int y) {
        for (int[] island : islands)
            if (island[0] == x && island[1] == y)
                return true;
        return false;
    }

    private List<Map<String, Integer>> convert(List<int[]> list) {
        List<Map<String, Integer>> result = new ArrayList<>();
        for (int[] pos : list) {
            Map<String, Integer> map = new HashMap<>();
            map.put("x", pos[0]);
            map.put("y", pos[1]);
            result.add(map);
        }
        return result;
    }
}
