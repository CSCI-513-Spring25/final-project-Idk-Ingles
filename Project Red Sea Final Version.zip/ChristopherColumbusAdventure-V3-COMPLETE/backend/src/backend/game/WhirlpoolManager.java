package backend.game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WhirlpoolManager {
    private List<int[]> whirlpools = new ArrayList<>();
    private final int SIZE = 18;

    public void spawnWhirlpools() {
        whirlpools.clear();
        Random rand = new Random();
        for (int i = 0; i < 2; i++) {
            whirlpools.add(new int[]{rand.nextInt(SIZE), rand.nextInt(SIZE)});
        }
    }

    public List<int[]> getPositions() {
        return whirlpools;
    }
}
