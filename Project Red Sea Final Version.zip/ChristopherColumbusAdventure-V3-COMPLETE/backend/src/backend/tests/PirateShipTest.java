package backend.tests;

import backend.ships.PirateShip;
import backend.strategy.ChaseStrategy;
import backend.strategy.PatrolStrategy;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PirateShipTest {

    @Test
    public void testChaseStrategyMovement() {
        PirateShip pirate = new PirateShip(0, 0, new ChaseStrategy());
        pirate.move(3, 3);
        assertTrue(pirate.getX() > 0 || pirate.getY() > 0,
                "Pirate should move closer to target using ChaseStrategy");
    }

    @Test
    public void testPatrolStrategyMovementBounds() {
        PirateShip pirate = new PirateShip(5, 5, new PatrolStrategy());
        pirate.move(0, 0); // doesn't use target, patrols instead
        assertTrue(pirate.getX() >= 0 && pirate.getY() >= 0,
                "PatrolStrategy should keep pirate within bounds");
    }
}
