package backend.tests;

import backend.game.GameState;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GameStateTest {

    @Test
    public void testSingletonInstance() {
        GameState instance1 = GameState.getInstance();
        GameState instance2 = GameState.getInstance();
        assertSame(instance1, instance2, "GameState should be singleton");
    }

    @Test
    public void testResetGameEasyLevel() {
        GameState game = GameState.getInstance();
        String result = game.resetGame("easy");
        assertEquals("New Game Started", result);
    }

    @Test
    public void testResetGameHardLevel() {
        GameState game = GameState.getInstance();
        String result = game.resetGame("hard");
        assertEquals("New Game Started", result);
    }
}
