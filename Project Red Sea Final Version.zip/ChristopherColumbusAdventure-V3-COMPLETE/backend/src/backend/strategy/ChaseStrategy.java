package backend.strategy;

import backend.ships.PirateShip;

public class ChaseStrategy implements Strategy {

    @Override
    public void move(PirateShip pirate, int targetX, int targetY) {
        int px = pirate.getX();
        int py = pirate.getY();

        if (px < targetX) px++;
        else if (px > targetX) px--;

        if (py < targetY) py++;
        else if (py > targetY) py--;

        pirate.setPosition(px, py);
    }
}
