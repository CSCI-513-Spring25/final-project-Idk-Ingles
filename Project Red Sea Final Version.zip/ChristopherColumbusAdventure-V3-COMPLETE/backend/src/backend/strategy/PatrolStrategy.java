package backend.strategy;

import backend.ships.PirateShip;

public class PatrolStrategy implements Strategy {
    private int step = 0;

    @Override
    public void move(PirateShip pirate, int targetX, int targetY) {
        int px = pirate.getX();
        int py = pirate.getY();

        switch (step % 4) {
            case 0 -> px = Math.min(17, px + 1); // right
            case 1 -> py = Math.min(17, py + 1); // down
            case 2 -> px = Math.max(0, px - 1);  // left
            case 3 -> py = Math.max(0, py - 1);  // up
        }

        step++;
        pirate.setPosition(px, py);
    }
}
