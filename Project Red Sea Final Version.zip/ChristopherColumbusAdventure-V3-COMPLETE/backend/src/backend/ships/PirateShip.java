package backend.ships;

import backend.strategy.Strategy;

public class PirateShip {
    private int x, y;
    private int prevX, prevY;
    private Strategy strategy;

    public PirateShip(int x, int y, Strategy strategy) {
        this.x = x;
        this.y = y;
        this.strategy = strategy;
        this.prevX = x;
        this.prevY = y;
    }

    public void move(int targetX, int targetY) {
        // Save previous position before moving
        prevX = x;
        prevY = y;
        strategy.move(this, targetX, targetY);
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void undoLastMove() {
        // Revert to previous position
        this.x = prevX;
        this.y = prevY;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
