package backend.ships;

import backend.strategy.ChaseStrategy;
import java.util.*;

public class PirateManager {
    private List<PirateShip> pirates = new ArrayList<>();
    private List<int[]> spawnPoints = new ArrayList<>();
    private List<Integer> freezeCounters = new ArrayList<>();
    private Stack<List<int[]>> history = new Stack<>();

    public void spawnPiratesForLevel(String level, int shipX, int shipY) {
        pirates.clear();
        spawnPoints.clear();
        freezeCounters.clear();

        int count = switch (level.toLowerCase()) {
            case "easy" -> 1;
            case "medium" -> 2;
            case "hard" -> 3;
            default -> 1;
        };

        Random rand = new Random();
        for (int i = 0; i < count; i++) {
            int x, y;
            do {
                x = rand.nextInt(18);
                y = rand.nextInt(18);
            } while (Math.abs(x - shipX) <= 2 && Math.abs(y - shipY) <= 2);

            PirateShip p = new PirateShip(x, y, new ChaseStrategy());
            pirates.add(p);
            spawnPoints.add(new int[]{x, y});
            freezeCounters.add(0); // no freeze initially
        }
    }

    public void movePirates(int targetX, int targetY, List<int[]> islands) {
        for (int i = 0; i < pirates.size(); i++) {
            PirateShip p = pirates.get(i);

            if (freezeCounters.get(i) > 0) {
                freezeCounters.set(i, freezeCounters.get(i) - 1); // reduce freeze duration
                continue;
            }

            int oldX = p.getX();
            int oldY = p.getY();
            p.move(targetX, targetY);

            for (int[] island : islands) {
                if (p.getX() == island[0] && p.getY() == island[1]) {
                    p.setPosition(oldX, oldY); // avoid island tile
                }
            }
        }
    }

    public void freezePiratesForTurns(int turns) {
        for (int i = 0; i < freezeCounters.size(); i++) {
            freezeCounters.set(i, turns);
        }
    }

    public boolean checkCollision(ChristopherColumbusShip ship) {
        for (int i = 0; i < pirates.size(); i++) {
            PirateShip p = pirates.get(i);
            if (p.getX() == ship.getX() && p.getY() == ship.getY()) {
                int[] spawn = spawnPoints.get(i);
                p.setPosition(spawn[0], spawn[1]);
                return true;
            }
        }
        return false;
    }

    public void saveHistory() {
        List<int[]> snapshot = new ArrayList<>();
        for (PirateShip p : pirates) {
            snapshot.add(new int[]{p.getX(), p.getY()});
        }
        history.push(snapshot);
    }

    public void undoPirates() {
        if (!history.isEmpty()) {
            List<int[]> last = history.pop();
            for (int i = 0; i < pirates.size(); i++) {
                pirates.get(i).setPosition(last.get(i)[0], last.get(i)[1]);
            }
        }
    }

    public List<int[]> getPositions() {
        List<int[]> out = new ArrayList<>();
        for (PirateShip p : pirates) {
            out.add(new int[]{p.getX(), p.getY()});
        }
        return out;
    }
}
