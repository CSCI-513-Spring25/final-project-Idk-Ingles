package backend.ships;
import java.util.Stack;


public class ChristopherColumbusShip {
    private int x, y;
    private int shieldCount = 0;
    private Stack<int[]> history = new Stack<>();
    private final int SIZE = 18;

    public ChristopherColumbusShip(int startX, int startY) {
        this.x = startX;
        this.y = startY;
    }

    public void setShieldCount(int count) {
        this.shieldCount = count;
    }

    public void consumeShield() {
        if (shieldCount > 0) shieldCount--;
    }

    public int getShieldCount() {
        return shieldCount;
    }

    public boolean move(String dir) {
        switch (dir) {
            case "right" -> {
                if (y < SIZE - 1) { y++; return true; }
            }
            case "left" -> {
                if (y > 0) { y--; return true; }
            }
            case "up" -> {
                if (x > 0) { x--; return true; }
            }
            case "down" -> {
                if (x < SIZE - 1) { x++; return true; }
            }
        }
        return false; // invalid move
    }
    

    public void savePosition() {
        history.push(new int[]{x, y});
    }

    public void undoPosition() {
        if (!history.isEmpty()) {
            int[] pos = history.pop();
            x = pos[0]; y = pos[1];
        }
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
}
