import React, { useState, useEffect } from 'react';
import './App.css';
import shipImg from './assets/ship.png';
import pirateImg from './assets/pirate.png';
import treasureImg from './assets/treasure.png';
import seamonsterImg from './assets/monster.png';
import whirlpoolImg from './assets/whirlpool.png';
import islandImg from './assets/island.png';
import logoImg from './assets/GameLogo.png';

interface Position {
  x: number;
  y: number;
}

function App() {
  const SIZE = 18;
  const [ccX, setCcX] = useState(0);
  const [ccY, setCcY] = useState(0);
  const [treasures, setTreasures] = useState<Position[]>([]);
  const [pirates, setPirates] = useState<Position[]>([]);
  const [monsters, setMonsters] = useState<Position[]>([]);
  const [whirlpools, setWhirlpools] = useState<Position[]>([]);
  const [islands, setIslands] = useState<Position[]>([]);
  const [boostReady, setBoostReady] = useState(false);
  const [boostArmed, setBoostArmed] = useState(false);
  const [boostFlashing, setBoostFlashing] = useState(false);
  const [shieldUses, setShieldUses] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [nameSubmitted, setNameSubmitted] = useState(false);
  const [level, setLevel] = useState('');
  const [introFact, setIntroFact] = useState('');

  const facts = [
    "Columbus made 4 voyages to the New World.",
    "He was sponsored by Spain in 1492.",
    "Blackbeard was one of the most feared pirates.",
    "The golden age of piracy was from 1650 to 1730.",
    "Whirlpools can suck down entire ships!",
    "Columbus believed he was in India.",
    "Pirates used clever sea strategies to avoid navies."
  ];

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (!gameStarted) return;
      if (e.key === 'ArrowUp') move('up');
      else if (e.key === 'ArrowDown') move('down');
      else if (e.key === 'ArrowLeft') move('left');
      else if (e.key === 'ArrowRight') move('right');
      else if (e.code === 'Space') boostMove();
      else if (e.key.toLowerCase() === 'u') undoMove();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [gameStarted, boostArmed]);

  const startGame = async (selectedLevel: string) => {
    setLevel(selectedLevel);
    setBoostReady(false);
    setGameStarted(true);
    await fetch(`/newgame?level=${selectedLevel}`);
    await loadGameState();
  };

  const newGame = () => {
    const fact = facts[Math.floor(Math.random() * facts.length)];
    setIntroFact(fact);
    setGameStarted(false);
    setNameSubmitted(false);
    setPlayerName('');
  };

  const loadGameState = async () => {
    const res = await fetch('/play?dir=none');
    const data = await res.json();
    updateState(data);
  };

  const move = async (dir: string) => {
    const moveDir = boostArmed ? "boost-" + dir : dir;
    if (boostArmed) setBoostArmed(false);

    const res = await fetch(`/play?dir=${moveDir}`);
    const data = await res.text();
    if (data === "Invalid move") {
      alert("❗ Invalid move: You're trying to go out of bounds!");
      return;
    }

    const stateRes = await fetch('/play?dir=none');
    const stateData = await stateRes.json();
    updateState(stateData);

    if (stateData.gameOver) {
      const message = stateData.gameResult === "win"
        ? "🏆 You found the treasure! Victory!"
        : "☠️ Game Over! You ran out of shields.";
      alert(message);
      setGameStarted(false);
    }
  };

  const boostMove = async () => {
    if (!boostReady) {
      alert("❌ Boost not available yet!");
      return;
    }
    setBoostArmed(true);
    alert("⚡ Boost Activated! Next move will jump 3 tiles!");
    setBoostFlashing(true);
    setTimeout(() => setBoostFlashing(false), 1000);
  };

  const undoMove = async () => {
    const res = await fetch(`/undo`);
    const data = await res.json();
    updateState(data);
  };

  const updateState = (data: any) => {
    setCcX(data.ccX);
    setCcY(data.ccY);
    setPirates(data.pirates || []);
    setMonsters(data.monsters || []);
    setIslands(data.islands || []);
    setTreasures(data.treasures || []);
    setWhirlpools(data.whirlpools || []);
    setBoostReady(data.boostReady || false);
    setShieldUses(data.shieldUses || 0);
  };

  const renderCell = (x: number, y: number) => {
    if (ccX === x && ccY === y) return <img src={shipImg} alt="Ship" className="cell-img" />;
    if (pirates.some(p => p.x === x && p.y === y)) return <img src={pirateImg} alt="Pirate" className="cell-img" />;
    if (monsters.some(m => m.x === x && m.y === y)) return <img src={seamonsterImg} alt="Monster" className="cell-img" />;
    if (treasures.some(t => t.x === x && t.y === y)) return <img src={treasureImg} alt="Treasure" className="cell-img" />;
    if (whirlpools.some(w => w.x === x && w.y === y)) return <img src={whirlpoolImg} alt="Whirlpool" className="cell-img" />;
    if (islands.some(i => i.x === x && i.y === y)) return <img src={islandImg} alt="Island" className="cell-img" />;
    return null;
  };

  if (!nameSubmitted) {
    return (
      <div className="start-screen">
        <img src={logoImg} alt="Logo" className="logo" style={{ width: '200px' }} />
        <h1 style={{ fontSize: '2.8rem' }}>Red Sea Treasure Hunt</h1>
        <div className="name-input">
          <input
            type="text"
            placeholder="Enter your name"
            value={playerName}
            onChange={e => setPlayerName(e.target.value)}
          />
        </div>
        <p style={{ fontSize: '1.3rem', fontWeight: 'bold', color: '#ffffaa' }}>{introFact}</p>
        <div className="button-group">
          <button onClick={() => {
            const fact = facts[Math.floor(Math.random() * facts.length)];
            setIntroFact(fact);
            setNameSubmitted(true);
          }}>Continue</button>
        </div>
      </div>
    );
  }

  if (!gameStarted) {
    return (
      <div className="start-screen">
        <img src={logoImg} alt="Logo" className="logo" style={{ width: '200px' }} />
        <h1 style={{ fontSize: '2.5rem' }}>Welcome, {playerName}!</h1>
        <p style={{ fontSize: '1.2rem', fontWeight: 'bold', color: '#ffffaa' }}>{introFact}</p>
        <div className="button-group">
          <button onClick={() => startGame('easy')}>Easy</button>
          <button onClick={() => startGame('medium')}>Medium</button>
          <button onClick={() => startGame('hard')}>Hard</button>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="top-banner">
        <img src={logoImg} alt="Logo" />
        Red Sea Treasure Hunt — <span style={{ fontWeight: 'bold' }}>Current Brave Sailor:</span> {playerName}
      </div>
      <div className="game-container">
        <div className="instructions">
          <h2>Instructions</h2>
          <ul>
            <li>Use Arrow Keys or buttons to move your ship.</li>
            <li>Press <b>Space</b> to Boost – it moves you 3 tiles in the next direction.</li>
            <li>Boost becomes available every few turns based on difficulty.</li>
            <li>Press <b>U</b> or click Undo to revert your last move.</li>
            <li>If you land on an island, pirates will freeze for three steps.</li>
            <li>If a pirate touches you, you lose a shield (🛡️).</li>
            <li>Landing on the treasure wins the game!</li>
            <li>Avoid 🏴‍☠️ Pirates, 🐙 Sea Monsters, 🌀 Whirlpools & 🏝️ Islands.</li>
          </ul>
        </div>

        <div className={`board ${boostFlashing ? 'boost-flash' : ''}`}>
          {Array.from({ length: SIZE }).map((_, row) => (
            <div key={row} className="board-row">
              {Array.from({ length: SIZE }).map((_, col) => (
                <div key={col} className="board-cell">
                  {renderCell(col, row)}
                </div>
              ))}
            </div>
          ))}
        </div>

        <div className="controls" style={{ fontSize: '1.1rem' }}>
          <button style={{ padding: '12px 16px' }} onClick={() => move('up')}>↑</button>
          <div>
            <button style={{ padding: '12px 16px' }} onClick={() => move('left')}>←</button>
            <button style={{ padding: '12px 16px' }} onClick={() => move('down')}>↓</button>
            <button style={{ padding: '12px 16px' }} onClick={() => move('right')}>→</button>
          </div>
          <button style={{ padding: '10px 20px' }} onClick={boostMove}>Boost</button>
          <button style={{ padding: '10px 20px' }} onClick={undoMove}>Undo</button>
          <button style={{ padding: '10px 20px' }} onClick={newGame}>New Game</button>
        </div>
      </div>
    </>
  );
}

export default App;
