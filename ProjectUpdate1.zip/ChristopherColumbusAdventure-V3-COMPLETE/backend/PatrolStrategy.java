// Alternate strategy for pirate movement.
public class PatrolStrategy implements Strategy {
    private int step = 0;

    @Override
    public void move(PirateShip pirate, int targetX, int targetY) {
        // Simple patrol pattern: right → down → left → up
        switch (step % 4) {
            case 0: pirate.setX(Math.min(9, pirate.getX() + 1)); break;
            case 1: pirate.setY(Math.min(9, pirate.getY() + 1)); break;
            case 2: pirate.setX(Math.max(0, pirate.getX() - 1)); break;
            case 3: pirate.setY(Math.max(0, pirate.getY() - 1)); break;
        }
        step++;
    }
}
