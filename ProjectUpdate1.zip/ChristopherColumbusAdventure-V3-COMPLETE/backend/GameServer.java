import fi.iki.elonen.NanoHTTPD;
import fi.iki.elonen.NanoHTTPD.Response;
import fi.iki.elonen.NanoHTTPD.IHTTPSession;
import java.io.IOException;

public class GameServer extends NanoHTTPD {

    public GameServer() throws IOException {
        super(8080);
        start(5000, false); // 5 second socket timeout
        System.out.println("Server started at http://localhost:8080");
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();

        if (uri.equals("/newgame")) {
            return newFixedLengthResponse(GameState.getInstance().resetGame());
        } else if (uri.startsWith("/play")) {
            String direction = session.getParms().get("dir");
            return newFixedLengthResponse(GameState.getInstance().move(direction));
        } else if (uri.equals("/undo")) {
            return newFixedLengthResponse(GameState.getInstance().undo());
        }

        return newFixedLengthResponse("Unknown command");
    }

    public static void main(String[] args) {
        try {
            new GameServer();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
