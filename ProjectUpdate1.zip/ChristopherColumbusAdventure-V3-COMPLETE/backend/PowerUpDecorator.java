// Decorator pattern for adding powerups to CC
public abstract class PowerUpDecorator extends ChristopherColumbusShip {
    protected ChristopherColumbusShip base;

    public PowerUpDecorator(ChristopherColumbusShip base) {
        super(base.getX(), base.getY());
        this.base = base;
    }

    public abstract String getPower();
}
