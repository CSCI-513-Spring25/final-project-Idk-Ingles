public class ShieldedShip extends PowerUpDecorator {
    public ShieldedShip(ChristopherColumbusShip base) {
        super(base);
    }

    @Override
    public String getPower() {
        return "Shielded";
    }
}
