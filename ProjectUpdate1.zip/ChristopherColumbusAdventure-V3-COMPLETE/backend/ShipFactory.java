// Factory pattern to create CC and Pirate ships
public class ShipFactory {

    public static PirateShip createPirate(int x, int y) {
        return new PirateShip(x, y);
    }

    public static PowerUpDecorator createPoweredCC(int x, int y) {
        return new ShieldedShip(new ChristopherColumbusShip(x, y));
    }
}
