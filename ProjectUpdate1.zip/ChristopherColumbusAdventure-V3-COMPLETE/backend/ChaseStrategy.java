// Strategy that chases Columbus.
public class ChaseStrategy implements Strategy {
    @Override
    public void move(PirateShip pirate, int targetX, int targetY) {
        if (pirate.getX() < targetX) pirate.setX(pirate.getX() + 1);
        else if (pirate.getX() > targetX) pirate.setX(pirate.getX() - 1);

        if (pirate.getY() < targetY) pirate.setY(pirate.getY() + 1);
        else if (pirate.getY() > targetY) pirate.setY(pirate.getY() - 1);
    }
}
