// Composite pattern for sea monsters
import java.util.ArrayList;
import java.util.List;

interface SeaEntity {
    int getX();
    int getY();
    void move();
}

class SeaMonster implements SeaEntity {
    private int x, y;
    public SeaMonster(int x, int y) { this.x = x; this.y = y; }
    public int getX() { return x; }
    public int getY() { return y; }
    public void move() { x = Math.max(0, x - 1); }
}

class SeaMonsterGroup implements SeaEntity {
    private List<SeaEntity> monsters = new ArrayList<>();

    public void add(SeaEntity m) {
        monsters.add(m);
    }

    public void move() {
        for (SeaEntity m : monsters) m.move();
    }

    public int getX() { return monsters.isEmpty() ? -1 : monsters.get(0).getX(); }
    public int getY() { return monsters.isEmpty() ? -1 : monsters.get(0).getY(); }

    public List<SeaEntity> getEntities() { return monsters; }
}
