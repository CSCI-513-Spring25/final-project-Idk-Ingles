// Observer + Strategy pirate movement
public class PirateShip {
    private int x, y;

    public PirateShip(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void moveToward(int targetX, int targetY) {
        if (x < targetX) x++;
        else if (x > targetX) x--;

        if (y < targetY) y++;
        else if (y > targetY) y--;
    }

    public int getX() { return x; }
    public int getY() { return y; }

    // 🔥 Add these setters
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
}


