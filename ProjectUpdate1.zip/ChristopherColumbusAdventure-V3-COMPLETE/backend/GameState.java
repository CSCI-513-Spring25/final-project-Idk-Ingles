// Game state class handling CC, pirates, treasure, and sea monsters
import org.json.JSONObject;
import java.util.*;

public class GameState {
    private static GameState instance;

    private int ccX, ccY;
    private int treasureX, treasureY;
    private final int SIZE = 10;
    private List<int[]> history = new ArrayList<>();
    private List<PirateShip> pirates = new ArrayList<>();
    private Random rand = new Random();

    private GameState() {
        resetGame();
    }

    public static GameState getInstance() {
        if (instance == null) instance = new GameState();
        return instance;
    }

    public String resetGame() {
        ccX = 0; ccY = 0;
        treasureX = rand.nextInt(SIZE);
        treasureY = rand.nextInt(SIZE);
        history.clear();
        pirates.clear();
        pirates.add(new PirateShip(5, 5));
        return toJSON().toString();
    }

    public String move(String direction) {
        history.add(new int[]{ccX, ccY});
        switch (direction) {
            case "up":    if (ccY > 0) ccY--; break;
            case "down":  if (ccY < SIZE - 1) ccY++; break;
            case "left":  if (ccX > 0) ccX--; break;
            case "right": if (ccX < SIZE - 1) ccX++; break;
        }

        for (PirateShip pirate : pirates) {
            pirate.moveToward(ccX, ccY);
        }

        return toJSON().toString();
    }

    public String undo() {
        if (!history.isEmpty()) {
            int[] last = history.remove(history.size() - 1);
            ccX = last[0];
            ccY = last[1];
        }
        return toJSON().toString();
    }

    public JSONObject toJSON() {
        JSONObject json = new JSONObject();
        json.put("ccX", ccX);
        json.put("ccY", ccY);
        json.put("treasureX", treasureX);
        json.put("treasureY", treasureY);

        List<JSONObject> pirateList = new ArrayList<>();
        for (PirateShip pirate : pirates) {
            JSONObject p = new JSONObject();
            p.put("x", pirate.getX());
            p.put("y", pirate.getY());
            pirateList.add(p);
        }
        json.put("pirates", pirateList);

        json.put("win", (ccX == treasureX && ccY == treasureY));
        return json;
    }
}
