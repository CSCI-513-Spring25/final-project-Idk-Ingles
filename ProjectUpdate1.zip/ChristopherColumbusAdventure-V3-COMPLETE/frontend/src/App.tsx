import React, { useState, useEffect } from 'react';
import './App.css';
import shipImg from './assets/ship.png';
import pirateImg from './assets/pirate.png';
import treasureImg from './assets/treasure.png';
import seamonsterImg from './assets/seamonster.png';
import shipwheelImg from './assets/shipwheel.png';
import whirlpoolImg from './assets/whirpool.png';
import logoImg from './assets/GameLogo.png';
import islandImg from './assets/island.png';

interface Pirate { x: number; y: number; }
interface SeaMonster { x: number; y: number; }
interface Whirlpool { x: number; y: number; }
interface Island { x: number; y: number; }

interface GameState {
  ccX: number;
  ccY: number;
  treasureX: number;
  treasureY: number;
  pirates: Pirate[];
  seaMonsters: SeaMonster[];
  whirlpools: Whirlpool[];
  islands: Island[];
  history: { x: number; y: number }[];
  moveCount: number;
  boostAvailable: boolean;
  boosting: boolean;
  level: 'Easy' | 'Medium' | 'Hard' | '';
  gameStarted: boolean;
  boostFrequency: number;
}

function App() {
  const SIZE = 18;
  const [state, setState] = useState<GameState>({
    ccX: 0, ccY: 0,
    treasureX: SIZE - 2, treasureY: SIZE - 2,
    pirates: [],
    seaMonsters: [],
    whirlpools: [],
    islands: [],
    history: [],
    moveCount: 0,
    boostAvailable: false,
    boosting: false,
    level: '',
    gameStarted: false,
    boostFrequency: 4,
  });

  useEffect(() => {
    if (state.gameStarted) setupGame();
  }, [state.gameStarted, state.level]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!state.gameStarted) return;
      if (event.key === 'ArrowUp') move('up');
      else if (event.key === 'ArrowDown') move('down');
      else if (event.key === 'ArrowLeft') move('left');
      else if (event.key === 'ArrowRight') move('right');
      else if (event.key.toLowerCase() === 'u') undo();
      else if (event.key.toLowerCase() === 'b') prepareBoost();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [state.gameStarted, state.boostAvailable, state.history]);

  const setupGame = () => {
    let pirates: Pirate[] = [];
    let whirlpools: Whirlpool[] = [];
    let islands: Island[] = [];
    let boostFrequency = 4;

    if (state.level === 'Easy') {
      pirates = [{ x: 5, y: 5 }];
      whirlpools = spawnRandom(5);
      islands = spawnRandom(6);
      boostFrequency = 2;
    } else if (state.level === 'Medium') {
      pirates = [{ x: 4, y: 4 }, { x: 10, y: 10 }];
      whirlpools = spawnRandom(4);
      islands = spawnRandom(4);
      boostFrequency = 3;
    } else if (state.level === 'Hard') {
      pirates = [{ x: 3, y: 3 }, { x: 7, y: 7 }, { x: 12, y: 12 }];
      whirlpools = spawnRandom(2);
      islands = spawnRandom(2);
      boostFrequency = 4;
    }

    setState((prev) => ({
      ...prev,
      pirates,
      whirlpools,
      islands,
      seaMonsters: [],
      ccX: 0, ccY: 0,
      history: [],
      moveCount: 0,
      boostAvailable: false,
      boosting: false,
      boostFrequency,
    }));
  };

  const spawnRandom = (count: number) => {
    const generated: { x: number; y: number }[] = [];
    while (generated.length < count) {
      const x = Math.floor(Math.random() * SIZE);
      const y = Math.floor(Math.random() * SIZE);
      if ((x !== 0 || y !== 0) && (x !== SIZE-2 || y !== SIZE-2)) {
        generated.push({ x, y });
      }
    }
    return generated;
  };

  const move = (dir: string) => {
    if (!state.gameStarted) return;

    let { ccX, ccY, moveCount, boostAvailable, boosting, history, pirates, seaMonsters, whirlpools } = state;

    history.push({ x: ccX, y: ccY });

    let newX = ccX;
    let newY = ccY;

    for (let step = 0; step < (boosting ? 2 : 1); step++) {
      if (dir === 'up') newY = Math.max(0, newY - 1);
      if (dir === 'down') newY = Math.min(SIZE - 1, newY + 1);
      if (dir === 'left') newX = Math.max(0, newX - 1);
      if (dir === 'right') newX = Math.min(SIZE - 1, newX + 1);
    }

    moveCount++;

    pirates = pirates.map(p => movePirate(p, newX, newY));

    if (pirates.some(p => p.x === newX && p.y === newY)) {
      alert('☠️ Captured by Pirates! Game Over!');
      setState((prev) => ({ ...prev, gameStarted: false }));
      return;
    }

    if (whirlpools.some(wp => wp.x === newX && wp.y === newY)) {
      alert('🌀 Whirlpool sucked you in!');
      const corners = [
        { x: 0, y: 0 }, { x: 0, y: SIZE - 1 }, { x: SIZE - 1, y: 0 }, { x: SIZE - 1, y: SIZE - 1 }
      ];
      const randomCorner = corners[Math.floor(Math.random() * corners.length)];
      newX = randomCorner.x;
      newY = randomCorner.y;
    }

    if (moveCount % 2 === 0) {
      const newMonster = spawnRandom(1)[0];
      seaMonsters.push({ x: newMonster.x, y: newMonster.y });
    }

    if (moveCount % 3 === 0) {
      whirlpools = spawnRandom(3);
    }

    setState((prev) => ({
      ...prev,
      ccX: newX,
      ccY: newY,
      moveCount,
      pirates,
      seaMonsters,
      whirlpools,
      history,
      boostAvailable: moveCount % prev.boostFrequency === 0,
      boosting: false,
    }));

    if (newX === state.treasureX && newY === state.treasureY) {
      alert('🎉 Congratulations! You found the Treasure!');
      setState((prev) => ({ ...prev, gameStarted: false }));
    }
  };

  const movePirate = (pirate: Pirate, targetX: number, targetY: number) => {
    let newX = pirate.x;
    let newY = pirate.y;
    if (pirate.x < targetX) newX++;
    else if (pirate.x > targetX) newX--;
    if (pirate.y < targetY) newY++;
    else if (pirate.y > targetY) newY--;
    return { x: newX, y: newY };
  };

  const prepareBoost = () => {
    if (state.boostAvailable) {
      setState((prev) => ({
        ...prev,
        boosting: true,
        boostAvailable: false,
      }));
    }
  };

  const undo = () => {
    if (state.history.length === 0) return;
    const last = state.history[state.history.length - 1];
    const newHistory = [...state.history];
    newHistory.pop();
    setState((prev) => ({
      ...prev,
      ccX: last.x,
      ccY: last.y,
      history: newHistory,
      moveCount: prev.moveCount - 1,
    }));
  };

  const newGame = () => {
    setState((prev) => ({ ...prev, gameStarted: false }));
  };

  const selectLevel = (level: 'Easy' | 'Medium' | 'Hard') => {
    setState((prev) => ({ ...prev, level, gameStarted: true }));
  };

  if (!state.gameStarted) {
    return (
      <div className="App start-screen">
        <img src={logoImg} alt="Game Logo" className="start-logo" />
        <h1 className="start-title">Escape Game - Red Sea Treasure Hunt</h1>
        <div className="difficulty-buttons">
          <button onClick={() => selectLevel('Easy')}>Easy</button>
          <button onClick={() => selectLevel('Medium')}>Medium</button>
          <button onClick={() => selectLevel('Hard')}>Hard</button>
        </div>
      </div>
    );
  }

  return (
    <div className="App">
      <header className="header">
        <img src={logoImg} alt="Game Logo" className="game-logo" />
        <div className="header-text">
          <h1>Escape Game - Red Sea Treasure Hunt</h1>
        </div>
      </header>

      <div className="content">
        <div className="instructions">
          <h2>Instructions</h2>
          <ul>
            <li>Move using ⬆️⬇️⬅️➡️ or buttons.</li>
            <li>Press B to Boost when available.</li>
            <li>Press U to Undo last move.</li>
            <li>Watch out for Pirates, Sea Monsters, Whirlpools!</li>
          </ul>
          <p>Moves: {state.moveCount}</p>
          {state.boostAvailable && <p>🔥 Boost Available!</p>}
        </div>

        <div className="grid-container">
          <table className="grid">
            <tbody>
              {[...Array(SIZE)].map((_, y) => (
                <tr key={y}>
                  {[...Array(SIZE)].map((_, x) => (
                    <td key={x}>
                      {(state.ccX === x && state.ccY === y) && <img src={shipImg} className="icon" />}
                      {state.treasureX === x && state.treasureY === y && <img src={treasureImg} className="icon" />}
                      {state.pirates.some(p => p.x === x && p.y === y) && <img src={pirateImg} className="icon" />}
                      {state.seaMonsters.some(m => m.x === x && m.y === y) && <img src={seamonsterImg} className="icon" />}
                      {state.whirlpools.some(wp => wp.x === x && wp.y === y) && <img src={whirlpoolImg} className="icon" />}
                      {state.islands.some(i => i.x === x && i.y === y) && <img src={islandImg} className="icon" />}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>

          <div className="controls">
            <img src={shipwheelImg} alt="Steering" className="wheel-icon" />
            <div className="buttons">
              <button onClick={() => move('up')}>↑</button>
              <div className="arrow-row">
                <button onClick={() => move('left')}>←</button>
                <button onClick={() => move('down')}>↓</button>
                <button onClick={() => move('right')}>→</button>
              </div>
            </div>
            <div className="extra-buttons">
              <button onClick={prepareBoost}>Boost (B)</button>
              <button onClick={undo}>Undo (U)</button>
              <button onClick={newGame}>New Game</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
